package dao;

import java.util.ArrayList;
import java.util.List;
import model.Estudiante;

public class EstudianteDAO {
    private List<Estudiante> estudiantes = new ArrayList<>();

    // Agregar estudiante
    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }

    // Listar todos los estudiantes
    public List<Estudiante> listar() {
        return estudiantes;
    }

    // Buscar estudiante por ID
    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }

    // Editar estudiante existente
    public boolean editar(Estudiante nuevoEstudiante) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == nuevoEstudiante.getId()) {
                estudiantes.set(i, nuevoEstudiante); // Reemplaza el objeto
                return true; // Editado con éxito
            }
        }
        return false; // No encontrado
    }

    // Eliminar estudiante por ID
    public boolean eliminar(int id) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == id) {
                estudiantes.remove(i);
                return true; // Eliminado con éxito
            }
        }
        return false; // No encontrado
    }
}
