package controller;

import dao.EstudianteDAO;
import model.Estudiante;
import java.util.List;

public class EstudianteController {
    private EstudianteDAO dao = new EstudianteDAO();

    // Metodo para crear estudiante
    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        dao.agregar(e);
    }

    // Obtener lista de todos los estudiantes
    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    // Buscar un estudiante por ID
    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }

    // Actualizar estudiante existente
    public boolean actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante existente = dao.buscarPorId(id);
        if (existente != null) {
            existente.setApellidos(apellidos);
            existente.setNombres(nombres);
            existente.setEdad(edad);
            return dao.editar(existente);
        }
        return false;
    }

    // Eliminar estudiante por ID
    public boolean eliminarEstudiante(int id) {
        return dao.eliminar(id);
    }
}
