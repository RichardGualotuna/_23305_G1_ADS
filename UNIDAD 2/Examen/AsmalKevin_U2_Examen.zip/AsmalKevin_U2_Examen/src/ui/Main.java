package ui;

import controller.EstudianteController;
import model.Estudiante;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;

//Clase Main que implementa una interfaz gráfica (GUI) usando Swing para gestionar un CRUD básico de estudiantes.

public class Main extends JFrame {
    // Controlador que maneja la lógica del CRUD
    private EstudianteController controller = new EstudianteController();

    // Componentes de entrada de datos
    private JTextField txtId = new JTextField(5);
    private JTextField txtApellidos = new JTextField(15);
    private JTextField txtNombres = new JTextField(15);
    private JTextField txtEdad = new JTextField(5);

    // Área de texto para mostrar resultados
    private JTextArea txtSalida = new JTextArea(10, 40);


     //Constructor que configura la interfaz de usuario

    public Main() {
        setTitle("Gestión de Estudiantes - CRUD");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Panel para campos de entrada
        JPanel panelInput = new JPanel(new GridLayout(5, 2));
        panelInput.add(new JLabel("ID:"));
        panelInput.add(txtId);
        panelInput.add(new JLabel("Apellidos:"));
        panelInput.add(txtApellidos);
        panelInput.add(new JLabel("Nombres:"));
        panelInput.add(txtNombres);
        panelInput.add(new JLabel("Edad:"));
        panelInput.add(txtEdad);

        // Botones de acción
        JButton btnAgregar = new JButton("Agregar");
        JButton btnEditar = new JButton("Editar");
        JButton btnEliminar = new JButton("Eliminar");
        JButton btnMostrar = new JButton("Mostrar Todo");

        // Panel para botones
        JPanel panelBotones = new JPanel();
        panelBotones.add(btnAgregar);
        panelBotones.add(btnEditar);
        panelBotones.add(btnEliminar);
        panelBotones.add(btnMostrar);

        // Área de salida con scroll
        txtSalida.setEditable(false);
        JScrollPane scroll = new JScrollPane(txtSalida);

        // Evento para botón Agregar
        btnAgregar.addActionListener((ActionEvent e) -> {
            int id = Integer.parseInt(txtId.getText());
            String apellidos = txtApellidos.getText();
            String nombres = txtNombres.getText();
            int edad = Integer.parseInt(txtEdad.getText());
            controller.crearEstudiante(id, apellidos, nombres, edad);
            mostrarMensaje("Estudiante agregado.");
        });

        // Evento para botón Editar
        btnEditar.addActionListener((ActionEvent e) -> {
            int id = Integer.parseInt(txtId.getText());
            String apellidos = txtApellidos.getText();
            String nombres = txtNombres.getText();
            int edad = Integer.parseInt(txtEdad.getText());
            boolean ok = controller.actualizarEstudiante(id, apellidos, nombres, edad);
            mostrarMensaje(ok ? "Estudiante actualizado." : "ID no encontrado.");
        });

        // Evento para botón Eliminar
        btnEliminar.addActionListener((ActionEvent e) -> {
            int id = Integer.parseInt(txtId.getText());
            boolean ok = controller.eliminarEstudiante(id);
            mostrarMensaje(ok ? "Estudiante eliminado." : "ID no encontrado.");
        });

        // Evento para botón Mostrar TODO
        btnMostrar.addActionListener((ActionEvent e) -> {
            mostrarEstudiantes();
        });

        // Agregar componentes al JFrame
        add(panelInput, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
        add(scroll, BorderLayout.SOUTH);

        // Ajustar tamaño y mostrar la ventana
        pack();
        setLocationRelativeTo(null); // Centra la ventana
        setVisible(true);
    }


     //Muestra un mensaje emergente (popup) con información al usuario

    private void mostrarMensaje(String mensaje) {
        JOptionPane.showMessageDialog(this, mensaje);
    }


     //Muestra en el área de texto todos los estudiantes registrados

    private void mostrarEstudiantes() {
        List<Estudiante> lista = controller.obtenerTodos();
        txtSalida.setText("");
        for (Estudiante e : lista) {
            txtSalida.append("ID: " + e.getId() + " | " +
                    e.getApellidos() + " " + e.getNombres() +
                    " | Edad: " + e.getEdad() + "\n");
        }
    }


     // Metodo principal para ejecutar el aplicativo

    public static void main(String[] args) {
        new Main();
    }
}
