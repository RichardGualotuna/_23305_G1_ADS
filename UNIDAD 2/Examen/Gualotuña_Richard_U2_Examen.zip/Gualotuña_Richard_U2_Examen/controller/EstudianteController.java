package controller;

import dao.EstudianteDAO;
import model.Estudiante;
import java.util.List;

public class EstudianteController {
    private EstudianteDAO dao = new EstudianteDAO();
    // Constructor

    public void crearEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante e = new Estudiante(id, apellidos, nombres, edad);
        dao.agregar(e);
    }
    //lista todos los estudiantes

    public List<Estudiante> obtenerTodos() {
        return dao.listar();
    }

    public Estudiante buscarEstudiante(int id) {
        return dao.buscarPorId(id);
    }

    public boolean eliminarEstudiante(int id) {
        return dao.eliminar(id);
    }
    // Actualiza un estudiante por ID
    public boolean actualizarEstudiante(int id, String apellidos, String nombres, int edad) {
        Estudiante actualizado = new Estudiante(id, apellidos, nombres, edad);
        return dao.actualizar(actualizado);
    }
}