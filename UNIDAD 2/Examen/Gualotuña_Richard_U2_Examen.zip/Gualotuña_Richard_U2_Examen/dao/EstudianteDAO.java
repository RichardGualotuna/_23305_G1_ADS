package dao;

import java.util.ArrayList;
import java.util.List;
import model.Estudiante;

public class EstudianteDAO {
    private List<Estudiante> estudiantes = new ArrayList<>();
    // Constructor
    //funcion para agregar estudiante

    public void agregar(Estudiante e) {
        estudiantes.add(e);
    }
    //funcion para listar estudiantes

    public List<Estudiante> listar() {
        return estudiantes;
    }
    //funcion para buscar estudiante por id

    public Estudiante buscarPorId(int id) {
        for (Estudiante e : estudiantes) {
            if (e.getId() == id) {
                return e;
            }
        }
        return null;
    }
    //funcion para eliminar estudiante por id 

    public boolean eliminar(int id) {
        Estudiante e = buscarPorId(id);
        if (e != null) {
            estudiantes.remove(e);
            return true;
        }
        return false;
    }
    //funcion para actualizar estudiante

    public boolean actualizar(Estudiante actualizado) {
        for (int i = 0; i < estudiantes.size(); i++) {
            if (estudiantes.get(i).getId() == actualizado.getId()) {
                estudiantes.set(i, actualizado);
                return true;
            }
        }
        return false;
    }
}