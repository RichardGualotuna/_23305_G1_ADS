package ui;

import controller.EstudianteController;
import model.Estudiante;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.*;
import java.util.List;
// CLase principal CRUD etsudiantes
public class Main {
    private static EstudianteController controller = new EstudianteController();
    private static DefaultTableModel tableModel;

    // Metodo principal para iniciar la aplicacioon
    public static void main(String[] args) {
        JFrame frame = new JFrame("Gestión de Estudiantes");
        frame.setSize(600, 400);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        JLabel labelId = new JLabel("ID:");
        labelId.setBounds(10, 10, 80, 25);
        frame.add(labelId);

        JTextField textId = new JTextField();
        textId.setBounds(100, 10, 160, 25);
        frame.add(textId);

        JLabel labelApellidos = new JLabel("Apellidos:");
        labelApellidos.setBounds(10, 40, 80, 25);
        frame.add(labelApellidos);

        JTextField textApellidos = new JTextField();
        textApellidos.setBounds(100, 40, 160, 25);
        frame.add(textApellidos);

        JLabel labelNombres = new JLabel("Nombres:");
        labelNombres.setBounds(10, 70, 80, 25);
        frame.add(labelNombres);

        JTextField textNombres = new JTextField();
        textNombres.setBounds(100, 70, 160, 25);
        frame.add(textNombres);

        JLabel labelEdad = new JLabel("Edad:");
        labelEdad.setBounds(10, 100, 80, 25);
        frame.add(labelEdad);

        JTextField textEdad = new JTextField();
        textEdad.setBounds(100, 100, 160, 25);
        frame.add(textEdad);

        JButton btnAgregar = new JButton("Agregar");
        btnAgregar.setBounds(280, 10, 100, 25);
        frame.add(btnAgregar);

        JButton btnActualizar = new JButton("Actualizar");
        btnActualizar.setBounds(280, 40, 100, 25);
        frame.add(btnActualizar);

        JButton btnEliminar = new JButton("Eliminar");
        btnEliminar.setBounds(280, 70, 100, 25);
        frame.add(btnEliminar);

        JButton btnBuscar = new JButton("Buscar por ID");
        btnBuscar.setBounds(280, 100, 100, 25);
        frame.add(btnBuscar);
        // Configuracion de la tabla
        String[] columnNames = { "ID", "Apellidos", "Nombres", "Edad" };
        tableModel = new DefaultTableModel(columnNames, 0);
        JTable table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBounds(10, 140, 560, 200);
        frame.add(scrollPane);
        // Configuracion de la tabla

        btnAgregar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(textId.getText());
                // verificar si el ID ya existe  
                if (controller.buscarEstudiante(id) != null) {
                    JOptionPane.showMessageDialog(frame, "Ya existe un estudiante con ese ID", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                //verificar si los campos estan vacios
                String apellidos = textApellidos.getText();
                String nombres = textNombres.getText();
                int edad = Integer.parseInt(textEdad.getText());
                if (apellidos.trim().isEmpty() || nombres.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Apellidos y Nombres no pueden estar vacíos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                //verificar si la edad es mayor que 0
                if (edad <= 0) {
                    JOptionPane.showMessageDialog(frame, "La edad debe ser mayor que 0", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                // Crear el estudiante y agregarlo a la lista
                controller.crearEstudiante(id, apellidos, nombres, edad);
                actualizarTabla();
                limpiarCampos(textId, textApellidos, textNombres, textEdad);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese un ID y edad válidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });


        // ActionListener para el boton Actualizar
        // Actualizar estudiante por ID
        btnActualizar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(textId.getText());
                String apellidos = textApellidos.getText();
                String nombres = textNombres.getText();
                int edad = Integer.parseInt(textEdad.getText());
                if (apellidos.trim().isEmpty() || nombres.trim().isEmpty()) {
                    JOptionPane.showMessageDialog(frame, "Apellidos y Nombres no pueden estar vacíos", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                if (edad <= 0) {
                    JOptionPane.showMessageDialog(frame, "La edad debe ser mayor que 0", "Error", JOptionPane.ERROR_MESSAGE);
                    return;
                }
                controller.actualizarEstudiante(id, apellidos, nombres, edad);
                actualizarTabla();
                limpiarCampos(textId, textApellidos, textNombres, textEdad);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese un ID y edad válidos", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });
        // ActionListener para el botón Eliminar
        // Eliminar estudiante por ID

        btnEliminar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(textId.getText());
                controller.eliminarEstudiante(id);
                actualizarTabla();
                limpiarCampos(textId, textApellidos, textNombres, textEdad);
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese un ID válido", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // ActionListener para el boton Buscar por ID
        // Buscar estudiante por ID

        btnBuscar.addActionListener(e -> {
            try {
                int id = Integer.parseInt(textId.getText());
                Estudiante estudiante = controller.buscarEstudiante(id);
                if (estudiante != null) {
                    textApellidos.setText(estudiante.getApellidos());
                    textNombres.setText(estudiante.getNombres());
                    textEdad.setText(String.valueOf(estudiante.getEdad()));
                    // Limpiar la tabla y agregar el estudiante encontrado
                    // mostrar solo el estudiante encontrado
                    tableModel.setRowCount(0);
                    tableModel.addRow(new Object[]{estudiante.getId(), estudiante.getApellidos(), estudiante.getNombres(), estudiante.getEdad()});
                } else {
                    JOptionPane.showMessageDialog(frame, "Estudiante no encontrado", "Error", JOptionPane.ERROR_MESSAGE);
                    limpiarCampos(textId, textApellidos, textNombres, textEdad);
                    actualizarTabla(); // Actualizar la tabla para mostrar todos los estudiantes
                }
            } catch (NumberFormatException ex) {
                JOptionPane.showMessageDialog(frame, "Por favor, ingrese un ID válido", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // ActionListener para el evento de clic en la tabla
        // Cargar los datos del estudiante seleccionado en los campos de texto
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int row = table.getSelectedRow();
                textId.setText(tableModel.getValueAt(row, 0).toString());
                textApellidos.setText(tableModel.getValueAt(row, 1).toString());
                textNombres.setText(tableModel.getValueAt(row, 2).toString());
                textEdad.setText(tableModel.getValueAt(row, 3).toString());
            }
        });
        
        actualizarTabla();
        frame.setVisible(true);
    }
     // Metodo para actualizar la tabla con los datos de los estudiantes
    // Actualiza la tabla con los datos de los estudiantes
    private static void actualizarTabla() {
        tableModel.setRowCount(0);
        List<Estudiante> estudiantes = controller.obtenerTodos();
        for (Estudiante e : estudiantes) {
            tableModel.addRow(new Object[]{e.getId(), e.getApellidos(), e.getNombres(), e.getEdad()});
        }
    }

    // Metodo para limpiar los campos de texto
    // Limpia los campos de texto
    private static void limpiarCampos(JTextField id, JTextField ape, JTextField nom, JTextField edad) {
        id.setText("");
        ape.setText("");
        nom.setText("");
        edad.setText("");
    }
}